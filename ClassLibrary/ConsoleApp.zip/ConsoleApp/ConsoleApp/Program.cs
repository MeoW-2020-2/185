﻿using System;
using CoreLib;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Utils.GenNumOrder("Иванов Иван Иванович", DateTime.Now));

            Console.Title = "CoreLib console app";
            Console.ReadKey();
        }
    }
}
